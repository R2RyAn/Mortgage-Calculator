package ca.yorku.mcalc;

import org.junit.Test;

import static org.junit.Assert.*;



